#include <l4/types.h>
#include <l4/thread.h>

extern void* L4_KernelInterface(
			L4_Word_t* apiVersion,
			L4_Word_t* apiFlags,
			L4_Word_t* kernelId);


