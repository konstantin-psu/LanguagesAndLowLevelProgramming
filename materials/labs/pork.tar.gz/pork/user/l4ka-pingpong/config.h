#ifndef CONFIG_H
#define CONFIG_H

#define L4_INLINE static inline

#endif
