#ifndef USERIO_H
#define USERIO_H
extern void setAttr(int a);
extern void cls(void);
extern void putchar(int c);
extern void puts(char* s);
extern void printf(const char *format, ...);
#endif
